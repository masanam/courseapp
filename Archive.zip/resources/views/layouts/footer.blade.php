<footer class="footer">
  <div class="container-fluid clearfix">
    <span class="text-muted d-block text-center text-sm-right d-sm-inline-block">Copyright ©  <a href="#" target="_blank">Brainzone.com</a> 2021</span>
    </span>
  </div>
</footer>