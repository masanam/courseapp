# Laravel CMS and API with Laravel Generator

=======
php artisan infyom:api_scaffold UserType --fromTable --tableName=user_types --datatables=true --prefix=admin

### Admin Panel or Web CMS
# LaravelCMSAPI
